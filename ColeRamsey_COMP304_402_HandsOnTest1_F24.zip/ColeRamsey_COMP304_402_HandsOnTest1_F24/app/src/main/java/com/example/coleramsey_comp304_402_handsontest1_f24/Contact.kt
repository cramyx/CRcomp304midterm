package com.example.coleramsey_comp304_402_handsontest1_f24

data class Contact(
    val name: String,
    val phone: String,
    val email: String,
    val isFriend: Boolean,
    val isFamily: Boolean,
    val isWork: Boolean
)
